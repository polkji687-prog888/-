
package com.farida.smart;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.WebChromeClient;
import android.webkit.PermissionRequest;
import android.webkit.JavascriptInterface;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.net.URL;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private WebView webView;

    private final ExecutorService executor =
            Executors.newSingleThreadExecutor();

    private final Handler handler =
            new Handler(Looper.getMainLooper());

    private static final String API_URL =
        "https://script.google.com/macros/s/AKfycbxqO_ZAhmeBWAd6c12-UyE1qNNT3_hdJ3aRap4RLjxsaoOMRIaB9MrZmxajv_JTHfTMoA/exec";

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient());

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    if (Build.VERSION.SDK_INT >= 23 &&
                        checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                            != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(
                            new String[]{Manifest.permission.RECORD_AUDIO}, 41
                        );
                    } else {
                        request.grant(request.getResources());
                    }
                });
            }
        });

        webView.addJavascriptInterface(new Object() {

            @JavascriptInterface
            public void askFarida(String message, String callbackName) {

                executor.execute(() -> {
                    JSONObject result;

                    try {
                        String encodedMessage =
                            URLEncoder.encode(message, "UTF-8");

                        URL url = new URL(
                            API_URL + "?message=" + encodedMessage
                            + "&callback=faridaNative"
                        );

                        HttpURLConnection connection =
                            (HttpURLConnection) url.openConnection();

                        connection.setRequestMethod("GET");
                        connection.setConnectTimeout(30000);
                        connection.setReadTimeout(60000);
                        connection.setInstanceFollowRedirects(true);

                        BufferedReader reader = new BufferedReader(
                            new InputStreamReader(
                                connection.getInputStream(),
                                StandardCharsets.UTF_8
                            )
                        );

                        StringBuilder response = new StringBuilder();
                        String line;

                        while ((line = reader.readLine()) != null) {
                            response.append(line);
                        }

                        reader.close();
                        connection.disconnect();

                        String body = response.toString();

                        int start = body.indexOf('(');
                        int end = body.lastIndexOf(')');

                        if (start < 0 || end <= start) {
                            throw new Exception(
                                "استجابة غير مفهومة من الخدمة."
                            );
                        }

                        String json = body.substring(start + 1, end);
                        result = new JSONObject(json);

                    } catch (Exception e) {
                        result = new JSONObject();

                        try {
                            result.put("success", false);
                            result.put(
                                "reply",
                                e.getMessage() == null
                                    ? "تعذر الاتصال بالخدمة."
                                    : e.getMessage()
                            );
                        } catch (Exception ignored) {
                        }
                    }

                    final JSONObject finalResult = result;

                    handler.post(() -> {
                        String safeCallback = callbackName.replaceAll(
                            "[^a-zA-Z0-9_$]", ""
                        );

                        if (!safeCallback.isEmpty() && webView != null) {
                            webView.evaluateJavascript(
                                "window['" + safeCallback + "']("
                                + finalResult.toString() + ");",
                                null
                            );
                        }
                    });
                });
            }

        }, "FaridaAndroid");

        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                new String[]{Manifest.permission.RECORD_AUDIO}, 41
            );
        }

        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("FaridaAndroid");
            webView.destroy();
            webView = null;
        }

        executor.shutdownNow();
        super.onDestroy();
    }
}
